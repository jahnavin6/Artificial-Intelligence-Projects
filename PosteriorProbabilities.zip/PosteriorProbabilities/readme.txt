Name : Jahnavi Nuthalapati
UTA ID : 1001827251
Programming language : Java
-------------------------------------

Program Compilation
javac posteriorprobability.java

-------------------------------------

Program Execution
java posteriorprobability [observations]

Eg: java posteriorprobability LCCCCCCCCCCCLLLLLLLLLLLLLLLLLLLLLLL

-------------------------------------