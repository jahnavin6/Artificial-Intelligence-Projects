/* Name :  Jahnavi Nuthalapati
 *  UTA ID: 1001827251*/

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.*;
import java.io.*;
import java.lang.*;

public class posteriorprobability
{

	public static void main(String[] args) throws IOException 
	{
		int val_cherries[]= {100, 75, 50, 25, 0};
		int val_lime[]= {0, 25, 50, 75, 100};
		double val_priors[]= {10, 20, 40, 20, 10}; 
		String Q = args[0];
		String final_result = "result.txt";
		BufferedWriter display = new BufferedWriter(new FileWriter( final_result ));
		System.out.println("Observation sequence Q : " +Q);
		display.write("Observation sequence Q : " +Q+"\n");
		System.out.println("Length of Q : " +Q.length());
		display.write("Length of Q : " +Q.length()+"\n");
        
        int p=0;
		    
		while(p<Q.length())
		{
			System.out.println("After Observation "+(p+1)+" = "+Q.charAt(p)+"\n");
			display.write("After Observation "+(p+1)+" = "+Q.charAt(p)+"\n");
			double ltd = 0.0, ltl=0.0;	
			

			int q=0;
			while(q<5)
			{
				ltd+= val_cherries[q]*val_priors[q]/10000.0;
				ltl+= val_lime[q]*val_priors[q]/10000.0;
				q++;
			}
			if (Q.charAt(p)=='C') 
			{
				int s=0;
				while(s<5)
				{
					val_priors[s]= val_cherries[s]*val_priors[s]/(ltd*100); 
					System.out.println("P(h"+(s+1)+" | Q) = "+String.format("%.09f",(val_priors[s]/100.00 )));
					display.write("P(h"+(s+1)+" | Q) = "+String.format("%.09f", (val_priors[s])/100.00) +"\n");
                    s++;
				}
		
			}
			else 
			{
				int t=0;
				while(t<5)
				{
					val_priors[t]= val_lime[t]*val_priors[t]/(ltl*100);
					System.out.println("P(h"+(t+1)+" | Q) = "+String.format("%.09f",(val_priors[t]/100.0))+"\n");
					display.write("P(h"+(t+1)+" | Q) = "+String.format("%.09f", (val_priors[t])/100.00)+"\n\n");
					t++;
				}
				
			}
			
			ltd = 0.0; ltl=0.0;
			
			int c=0;
			while(c<5)
			{
				ltd+= val_cherries[c]*val_priors[c]/10000.0;
				ltl+= val_lime[c]*val_priors[c]/10000.0;
				c++;
			}
			
			
			
			System.out.println("Probability that the next candy we pick will be C, given Q: "+String.format("%.09f", (ltd)));
			display.write("Probability that the next candy we pick will be C, given Q: "+String.format("%.09f", (ltd)));
			System.out.println("Probability that the next candy we pick will be L, given Q: "+String.format("%.09f", (ltl)));
			display.write("Probability that the next candy we pick will be C, given Q: "+String.format("%.09f", (ltl)));
			System.out.println();
			display.write("\n");
			p++;
		}
		
		display.close();
	}

}
