NAME   :  Jahnavi Nuthalapati
ID     :  1001827251

Class Names

 -- find_route (MAIN FUNCTION)
 -- graph
 -- change1


The code given will help calculating the cost from origin place to final destination.

RUN INSTRUCTIONS

The valid arguments can be given like --

Language used is JAVA ---

@complile
  javac find_route.java

@run
	java find_route uninf/inf input_filename source destination
	Example : java find_route uninf/inf input123.txt Luebeck Hamburg

