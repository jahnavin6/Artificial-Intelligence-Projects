/**
 *  @Jahnavi Nuthalapati
 *  1001827251
 */
import java.io.*;
import java.util.*;



class graph {
    static int getPosition(graph.tree_n1 node, ArrayList<graph.tree_n1> graph) {
        for (int i = 0; graph.size() >= i; i++) {
            if (graph.get(i).toString().equals(node.toString())) {
                return i;
            }
        }
        return -1;
    }

    static class grp_trv {

        public final tree_n1 final_1;
        public final int totalslcst;

        public grp_trv(tree_n1 destNode, int slcst) {
            totalslcst = slcst;
            final_1 = destNode;
        }

        public double getslcst() {
            return totalslcst;
        }
        public tree_n1 getfinal_1() {
            return final_1;
        }

        public String toString() {
            return final_1.toString();
        }
    }

    static class tree_n1 implements Comparator<tree_n1> {

        public final String plce1;
        public ArrayList<grp_trv> cities;
        public tree_n1 mainNode;
        public int pathslcst;

        public tree_n1(String currplce1) {
            plce1 = currplce1;
            cities = new ArrayList<grp_trv>();
        }

        public String toString() {
            return plce1;
        }

        public void addplce1(tree_n1 final_1, int slcst) {
            grp_trv objGraphData = new grp_trv(final_1, slcst);
            cities.add(objGraphData);
        }

     
        public int calculateslcst() {
            for(grp_trv e : cities) {
                if(e.final_1.toString().equals(mainNode.toString()))
                    return e.totalslcst;
            }
            return 0;
        }

        
        @Override
        public int compare(tree_n1 node1, tree_n1 node2){
            if(node1.pathslcst < node2.pathslcst)
                return -1;
            else if (node1.pathslcst > node2.pathslcst)
                return 1;
            else
                return 0;
        }

        @Override
        public boolean equals(Object obj){
            if((obj instanceof tree_n1) && plce1.equals(obj.toString()))
                return true;
            return false;
        }
    }
}

class change1 {
    static int n1_cnt ;

    static void csproced(graph.tree_n1 orig_1Node, graph.tree_n1 final_1) {
       

        orig_1Node.pathslcst = 0;
        n1_cnt = 0;

        PriorityQueue<graph.tree_n1> queue = new PriorityQueue<>(25, orig_1Node);

        queue.add(orig_1Node);
        graph.tree_n1 current = null;
        if(!orig_1Node.equals(final_1)) {
            n1_cnt++;
        }

        HashSet<graph.tree_n1> closed = new HashSet<>();

        do {
            current = queue.poll();

            closed.add(current);
            for (graph.grp_trv e : current.cities) {
                graph.tree_n1 child = e.final_1;
                int slcst = e.totalslcst;
                if (queue.contains(child) == false) {
                    child.pathslcst = current.pathslcst + slcst;
                    if (closed.contains(child) == false) {
                        child.mainNode = current;
                        queue.add(child);
                        n1_cnt++;
                    }
                } else if ((queue.contains(child) == true) && (child.pathslcst > current.pathslcst + slcst)) {
                    child.mainNode = current;
                    queue.remove(child);
                    queue.add(child);
                }
            }
        } while (queue.isEmpty() == false);
    }

    static ArrayList<graph.tree_n1> gen_grph(String filename) {
        ArrayList<graph.tree_n1> map = new ArrayList<graph.tree_n1>();
        File file = new File(filename);
        try {
            InputStream in = new FileInputStream(file);


            BufferedReader parser = new BufferedReader(new InputStreamReader(in));
            String line;
            while ((line = parser.readLine()) != null) {
                if (line.equals("END OF INPUT")) {
                    break;
                }
                String[] values = line.toLowerCase().split(" ");
                String orig_1plce1 = values[0].toString();
                String final_1plce1 = values[1].toString();
                int slcst = Integer.parseInt(values[2]);

                graph.tree_n1 plce1_orig1 = new graph.tree_n1(orig_1plce1);
                graph.tree_n1 final_1 = new graph.tree_n1(final_1plce1);
                int index = -1;

                if (map.contains(plce1_orig1) == true) {
                    index = graph.getPosition(plce1_orig1, map);
                    plce1_orig1 = map.get(index);
                }

                if (map.contains(final_1) == true) {
                    index = graph.getPosition(final_1, map);
                    final_1 = map.get(index);
                    final_1.addplce1(plce1_orig1, slcst);
                    index = graph.getPosition(final_1, map);
                    map.set(index, final_1);
                } else {
                    final_1.addplce1(plce1_orig1, slcst);
                    map.add(final_1);
                }

                plce1_orig1.addplce1(final_1, slcst);


                if (map.contains(plce1_orig1) == true) {
                    index = graph.getPosition(plce1_orig1, map);
                    map.set(index, plce1_orig1);
                } else {
                    map.add(plce1_orig1);
                }
            }
            parser.close();
        } catch (FileNotFoundException e) {
            System.out.println(e);
        } catch (NumberFormatException e) {
            System.out.println("End of Line");
        } catch (IOException e)
        {
            System.out.println(e);
        }
        return map;
    }

}


public class find_route {
    public static void main(String[] arrArgument) {

        if (arrArgument.length < 3) {
            System.out.println("Wrong usage!!");
            System.out.println("3 Params required: inputfile node_orig_1 node_dest1");
            System.exit(0);
        }


        ArrayList<graph.tree_n1> graph = change1.gen_grph(arrArgument[1]);
        
        graph.tree_n1 orig_1 = null, final_1 = null;

        for (graph.tree_n1 node : graph) {
            if (!node.toString().equals(arrArgument[2].toLowerCase()))
            {

                if (!node.toString().equals(arrArgument[3].toLowerCase()))
                {
                } else {
                    final_1 = node;
                }
            } else {

                orig_1 = node;
            }
        }

        int lgth = 0;

       

        if (!arrArgument[0].equals("inf")) {
            change1.csproced(orig_1, final_1);

            
            List<graph.tree_n1> route = new ArrayList<>();
            for (graph.tree_n1 node = final_1; node != null; node = node.mainNode) {
                route.add(node);
            }
            Collections.reverse(route);

            
            lgth = route.stream().filter((node) -> (node.mainNode != null)).map((node) -> node.calculateslcst()).reduce(lgth, Integer::sum);

            
            disp_ans(lgth, change1.n1_cnt, route);
        }
    }

    private static void disp_ans(int lgth, int n1_cnt, List<graph.tree_n1> route) {
        if (lgth <= 0){
            System.out.println("lgth: infinity");
            System.out.println("Number of nodes explored: "+change1.n1_cnt);
            System.out.println("route: ");
            System.out.println("none");
        }else{
            System.out.println("lgth: " + lgth + " km");
            System.out.println("Number of nodes explored: "+change1.n1_cnt);
            System.out.println("route: ");
            route.stream().filter((node) -> (node.mainNode != null)).forEachOrdered((node) -> {
                System.out.println(node.mainNode + "   to   " + node + ", " + node.calculateslcst() + " km");
            });
        }
    }

}

