Name : Jahnavi Nuthalapati
UTA ID : 1001827251
Programming language : Java
-------------------------------------

Program Compilation
javac bnet.java

-------------------------------------

Program Execution
java bnet [observations]

Eg: java bnet Bf At Mt

-------------------------------------