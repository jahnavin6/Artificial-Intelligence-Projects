/* Name : Jahnavi Nuthalapati
 * UTA ID:1001827251*/

import java.util.Scanner;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.*;
import java.io.*;
import java.lang.*;


public class bnet 
{ 

	public static double probability_finding(boolean b1, boolean e1, boolean a1, boolean j1, boolean m1)
	{
		
		double earthquake_num=0.00;
		if(e1) 
		{
			earthquake_num=EQ_node;
		}
		else 
		{
			earthquake_num= 1-EQ_node;
		}

		double burglary_num=0.00;
		if(b1) 
		{
			burglary_num=Burglary_node;

		}
		else 
		{
			burglary_num = 1-Burglary_node;
		}
		
		double alarm_num = 0.00;
		if(a1)
		 {
			if(b1==true && e1==true )
				alarm_num = Alarm_node[0];
			else if(b1==true && e1==false )
				alarm_num = Alarm_node[1];
			else if(b1==false && e1==true )
				alarm_num = Alarm_node[2];
			else if(b1==false && e1==false )
				alarm_num = Alarm_node[3];}
		else
		{
			if(b1==true && e1==true )
				alarm_num = 1-Alarm_node[0];
			else if(b1==true && e1==false )
				alarm_num = 1-Alarm_node[1];
			else if(b1==false && e1==true )
				alarm_num = 1-Alarm_node[2];
			else if(b1==false && e1==false )
				alarm_num = 1-Alarm_node[3];}

		double johncall_num = 0.00;
		if(j1)
		 {
			if(a1==true)
				johncall_num = JohnCalls_node[0];
			else if(a1==false )
				johncall_num = JohnCalls_node[1];

		}

		else
		{
			if(a1==true)
				johncall_num =1-JohnCalls_node[0];
			else if(a1==false )
				johncall_num =1-JohnCalls_node[1];
		}

		double marycall_num = 0.00;
		if(m1) 
		{
			if(a1==true)
				marycall_num = Marycalls_node[0];
			else if(a1==false )
				marycall_num = Marycalls_node[1];
		}

		else
		{
			if(a1==true)
				marycall_num =1-Marycalls_node[0];
			else if(a1==false )
				marycall_num =1-Marycalls_node[1];
		}
		return burglary_num*earthquake_num*alarm_num*johncall_num*marycall_num; 
	}

	static double Burglary_node=0.001; 
	static double EQ_node=0.002;
	static double Alarm_node[]= {0.95,0.94,0.29,0.001};  
	static double JohnCalls_node[]= {0.90,0.05};
	static double Marycalls_node[]= {0.70,0.01};

	static ArrayList<String> first_store = new ArrayList<String>();
	static ArrayList<String> first_store2 = new ArrayList<String>();

	public static void main(String[] args) throws Exception 
	{
		
		int var_b=0;
		int var_e=0;
		int var_a=0;
		int var_j=0;
		int var_m=0;

		if (args.length <1 || args.length > 6) 
		{ 
			System.exit(0);
		}
		
		int token =-1;
        int p,q,s;
		for(p=0;p<args.length;p++) 
		{ 
			if(args[p].equals("given"))
			{
				token=0;
				continue;
			}
			if(token==-1)
			{
				first_store.add(args[p]);
			}
			else
			{
				first_store2.add(args[p]);
			}

		}	
		if (first_store.size() <1 || first_store.size() > 6) 
		{ 
			System.exit(0);
		}
		if(token==0) {
			if (first_store2.size() <1 || first_store2.size() > 4) 
			{
				System.exit(0);
			}		
		}


		first_store.addAll(first_store2); 
		
		for(q=0;q< first_store.size();q++)
		 {  
			
			if (!first_store.contains("Bt")&&!first_store.contains("Bf"))
			 {
				first_store.add("Bt");
				first_store.add("Bf");
				var_b=1;
			}
			if (!first_store.contains("Et")&&!first_store.contains("Ef")) 
			{
				first_store.add("Et");
				first_store.add("Ef");
				var_e=1;
			}
			if (!first_store.contains("At")&&!first_store.contains("Af")) 
			{
				first_store.add("At");
				first_store.add("Af");
				var_a=1;}
			if (!(first_store.contains("Jt"))&&!first_store.contains("Jf")) 
			{
				first_store.add("Jt");
				first_store.add("Jf");
				var_j=1;
			}
			if (!first_store.contains("Mt")&&!first_store.contains("Mf"))
			 {
				first_store.add("Mt");
				first_store.add("Mf");
				var_m=1;
			}
		}

		double upper = find_prob_nodes(var_b, var_e, var_a, var_j, var_m, first_store);
		
		if(first_store2.size()==0) 
		{
			System.out.println("Computed Probability: "+upper);
		}

		var_b=var_e=var_a=var_j=var_m=0;

		for(s=0;s< first_store2.size();s++)
		 {
				
			if (!first_store2.contains("Bt")&&!first_store2.contains("Bf")) 
			{
				first_store2.add("Bt");
				first_store2.add("Bf");
				var_b=1;
			}
			if (!first_store2.contains("Et")&&!first_store2.contains("Ef"))
			 {
				first_store2.add("Et");
				first_store2.add("Ef");
				var_e=1;
			}
			if (!first_store2.contains("At")&&!first_store2.contains("Af"))
			 {
				first_store2.add("At");
				first_store2.add("Af");
				var_a=1;
			}
			if (!first_store2.contains("Jt")&&!first_store2.contains("Jf")) 
			{
				first_store2.add("Jt");
				first_store2.add("Jf");
				var_j=1;
			}
			if (!first_store2.contains("Mt")&&!first_store2.contains("Mf")) 
			{
				first_store2.add("Mt");
				first_store2.add("Mf");
				var_m=1;
			}
		}
		double lower = find_prob_nodes(var_b, var_e, var_a, var_j, var_m, first_store2);
		if(first_store2.size()>0) {
			System.out.println("Computed Probability: "+upper/lower);
		}
		
	}
	

	public static double find_prob_nodes(int bb1,int ee1,int aa1,int jj1,int mm1,ArrayList<String> a_method) 
	{
		double  find_p=0.0;
		Boolean flag_b=false;
		Boolean flag_e=false;
		Boolean flag_a=false;
		Boolean flag_j=false;
		Boolean flag_m=false;

		
		if(aa1==0) 
		{
			if(a_method.contains("At")) 
			{
				flag_a=true;
			}
			else flag_a=false;
		}
		if(bb1==0) 
		{
			if(a_method.contains("Bt")) 
			{
				flag_b=true;
			}
			else flag_b=false;
		}
		if(ee1==0)
		{
			if(a_method.contains("Et")) 
			{
				flag_e=true;
			}
			else flag_e=false;
		}
		if(mm1==0) 
		{
			if(a_method.contains("Mt")) 
			{
				flag_m=true;
			}
			else flag_m=false;
		}
		if(jj1==0) 
		{
			if(a_method.contains("Jt")) 
			{
				flag_j=true;
			}
			else flag_j=false;
		}

		int i1=0;
		while(i1<=bb1)
		{
			int i2=0;
			while(i2<=ee1)
			{
				int i3=0;
				while(i3<=aa1)
				{
					int i4=0;
					while(i4<=jj1)
					{
						int i5=0;
						while(i5<=mm1)
						{
							find_p=find_p+probability_finding(flag_b, flag_e, flag_a, flag_j, flag_m);
							if(mm1==1 && flag_m==false) 
								flag_m=true;
							else if(mm1==1 && flag_m==true) 
								flag_m=false;
							i5++;
						}
						if(jj1==1 && flag_j==false) 
							flag_j=true;
						else if(jj1==1 && flag_j==true) 
							flag_j=false;
						i4++;
					}
                    if(aa1==1 && flag_a==false) 
                    	flag_a=true;
					else if(aa1==1 && flag_a==true) 
						flag_a=false;
					i3++;
				}
				if(ee1==1 && flag_e==false) 
					flag_e=true;
				else if(ee1==1 && flag_e==true) 
					flag_e=false;
				i2++;
			}
			if(bb1==1 && flag_b==false) 
				flag_b=true;
			else if(bb1==1 && flag_b==true) 
				flag_b=false;
			i1++;	
		}		
		return find_p;
	}
}
