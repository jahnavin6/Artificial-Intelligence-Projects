public class symbols {
    
    String symbol_name;
    
}
