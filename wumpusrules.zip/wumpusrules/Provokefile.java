/*Author: Jahnavi Nuthalapati
 * ID No: 1001827251 */

import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Enumeration;
import java.util.HashMap;


public class Provokefile {
    
    static HashMap<String, Boolean> var1;
    public LinkedList getsymbols(LogicalExpression kstore, HashMap m1)
        {
            LinkedList<symbols> symbollist = new LinkedList<symbols>();
            boolean if_present = false;
            for(symbols kb_symbol : kstore.symbollist)
            {
                if_present = false;
                for(symbols sml : symbollist)
                {
                    if(sml.symbol_name.equalsIgnoreCase(kb_symbol.symbol_name))
                    {
                        if_present = true;
                        break;
                        
                    }
                } 
                if(if_present == false && !m1.containsKey(kb_symbol.symbol_name))
                    symbollist.add(kb_symbol);
            }
            return symbollist;
        }
       
        public boolean findExpression(LogicalExpression kstore, LogicalExpression statement, LinkedList symbollist, HashMap m1)
        {
            if(symbollist.isEmpty())
            {
                if(checktrue(kstore, m1))
                   return checktrue(statement, m1);
                else
                {
                    return true;
                }
            }
            else
            {
                
                symbols first = new symbols();
                first = (symbols) symbollist.poll();
                HashMap<String, Boolean> temp_var1 = new HashMap<String, Boolean>(m1);
                HashMap<String, Boolean> temp_model = new HashMap<String, Boolean>(m1);
                LinkedList<symbols> temp_list = new LinkedList<symbols>();
                ListIterator<symbols> listIterator = symbollist.listIterator();
                while (listIterator.hasNext())
                {
                    temp_list.add(listIterator.next());
                }
                    boolean symbol_true = findExpression(kstore, statement, symbollist, ext(first, true, temp_var1));
                    symbollist = temp_list;
                    boolean symbol_false = findExpression(kstore, statement, symbollist, ext(first, false, temp_model));
                    return symbol_true && symbol_false;
            }
        }

         public boolean TTE(LogicalExpression kstore,LogicalExpression statement, HashMap m1)
        {
            var1 = new HashMap<String, Boolean>(m1);
           return findExpression(kstore, statement, getsymbols(kstore, m1), m1);
        }
        public boolean checktrue(LogicalExpression statement, HashMap m1)
        {
            if(statement.getUniqueSymbol() != null)
            {
                String aa = statement.getUniqueSymbol();
                boolean val;
                if(var1.containsKey(aa))
                    val= (Boolean) var1.get(aa);
                else
                    val= (Boolean) m1.get(aa);
                return val;
            }
            else if(statement.getConnective().equalsIgnoreCase("if"))
            {
                LogicalExpression leftExpression, rightExpression;
                boolean leftvalue = false, right_pl_value = false;
                int count = 0;
                String to_be_true = null;
                for( Enumeration e = statement.getSubexpressions().elements(); e.hasMoreElements(); ) 
                {
                    if(++count == 1)
                    {
                        leftExpression = ( LogicalExpression )e.nextElement();
                        leftvalue = checktrue(leftExpression, m1);
                    }
                    else if(++count >= 2)
                    {
                        rightExpression = ( LogicalExpression )e.nextElement();
                        right_pl_value = checktrue(rightExpression, m1);
                    }
                }
                if(leftvalue == true && right_pl_value == false)
                {
                    if(!var1.containsKey(to_be_true))
                        var1.put(to_be_true, leftvalue);
                        return false;
                }
                return true;
            }
            else if(statement.getConnective().equalsIgnoreCase("or"))
            {
                LogicalExpression nextExpression;
                for( Enumeration e = statement.getSubexpressions().elements(); e.hasMoreElements(); ) 
                {
                    nextExpression = ( LogicalExpression )e.nextElement();
                    if (checktrue(nextExpression, m1) == true)
                        return true;
                }
                return false;
            }
            else if(statement.getConnective().equalsIgnoreCase("xor"))
            {
                LogicalExpression nextExpression;
                int count = 0;
                for( Enumeration e = statement.getSubexpressions().elements(); e.hasMoreElements(); ) 
                {
                    nextExpression = ( LogicalExpression )e.nextElement();
                    if (checktrue(nextExpression, m1) == true)
                        count++;
                }
                if(count == 1)
                    return true;
                else
                    return false;
            }
            else if(statement.getConnective().equalsIgnoreCase("iff"))
            {
                LogicalExpression leftExpression, rightExpression;
                boolean left_pl_value = false, right_pl_value = false;
                String to_be_true = null;
                int count = 0;
                for( Enumeration e = statement.getSubexpressions().elements(); e.hasMoreElements(); ) 
                {
                    
                    if(++count == 1)
                    {
                        leftExpression = ( LogicalExpression )e.nextElement();
                        to_be_true = leftExpression.getUniqueSymbol();
                        left_pl_value = checktrue(leftExpression, m1);
                    }
                    else if(++count >= 2)
                    {
                        rightExpression = ( LogicalExpression )e.nextElement();
                        right_pl_value = checktrue(rightExpression, m1);
                    }
                }
                if(left_pl_value == right_pl_value)
                {
                    if(!var1.containsKey(to_be_true))
                        var1.put(to_be_true, left_pl_value);
                    return true;
                }
                return false;
            }
            else if(statement.getConnective().equalsIgnoreCase("and"))
            {
                LogicalExpression nextExpression;
                for( Enumeration e = statement.getSubexpressions().elements(); e.hasMoreElements(); ) 
                {
                    nextExpression = ( LogicalExpression )e.nextElement();
                    if (checktrue(nextExpression, m1) == false)
                        return false;
                }
                return true;
            }
            else if(statement.getConnective().equalsIgnoreCase("not"))
            {
                LogicalExpression nextExpression;
                for( Enumeration e = statement.getSubexpressions().elements(); e.hasMoreElements(); ) 
                {
                    nextExpression = ( LogicalExpression )e.nextElement();
                    if (checktrue(nextExpression, m1) == false)
                        return true;
                    
                }
                return false;
            }
            else
                return false;
        }


        public HashMap ext(symbols first, boolean value, HashMap m1)
        {
            m1.put(first.symbol_name, value);
            return m1;
        }
}
