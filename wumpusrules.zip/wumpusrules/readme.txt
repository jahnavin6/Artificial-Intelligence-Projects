Programming Assignment

Name: Jahnavi Nuthalapati
Id No: 1001827251

Programming language used: Java

(In Terminal)
--- Code Compilation 
javac CheckTrueFalse.java

--- Code Execution 
And an example given in the question can be followed

java CheckTrueFalse a.txt b.txt c.txt


(NOTE : As a Provokefile is a wrapper class file it may encounter a warning when it's executed initially. So this warning shouldn't affect the execution)
