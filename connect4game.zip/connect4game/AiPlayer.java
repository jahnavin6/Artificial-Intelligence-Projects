
 /* Author : Jahnavi Nuthalapati
   UTA ID : 1001827251*/
import java.util.*;
public class AiPlayer
{

	
	public int player;
	public AiPlayer()
	{
	}
	
	public int findBestPlay(GameBoard ongoingplay, int curr_depth ) 
	{
		int alp=Integer.MIN_VALUE; 
		int bet=Integer.MAX_VALUE;  
		int large_value = Integer.MIN_VALUE;
		int largest = -1;
		int v=alp;

		for (int i=0; i<7;i++) {
			if(ongoingplay.isValidPlay(i)) {
				GameBoard temp = new GameBoard(ongoingplay.getGameBoard());
				temp.playPiece(i);
				v =minvalue(temp,alp,bet,curr_depth-1);
				if( v > large_value)
				{
					large_value =v;
					largest=i;
				}
			}

		}
		return largest;


	}

	int maxvalue(GameBoard state,int alp,int bet, int curr_depth) 
	{
		if(state.getPieceCount()==42)
			return utility(state);
		if( curr_depth == 0 )
			return evaluate(state);
		else {
			
			ArrayList<GameBoard> subelements = new ArrayList<GameBoard>(); 
			subelements=	getPossibleBoards(state);

			int v = Integer.MIN_VALUE;
			for (int i = 0; i < subelements.size(); i++) {
				v = Math.max(v, minvalue( subelements.get(i), alp, bet, curr_depth-1));
				if(v>=bet) {
					return v;
				}
				alp = Math.max(alp, v);
			}
			return v;

		}


	}
	 
	public int minvalue(GameBoard state,int alp,int bet, int curr_depth)
	{
		if(state.getPieceCount()==42) 
			return utility(state);
		if( curr_depth == 0 )
			return evaluate(state);
		else {
			ArrayList<GameBoard> subelements = new ArrayList<GameBoard>(); 
			subelements=	getPossibleBoards(state);

			int v = Integer.MAX_VALUE;
			for (int i = 0; i < subelements.size(); i++) {
				v = Math.min(v, maxvalue(subelements.get(i), alp, bet,curr_depth-1));
				if(v<=alp) {
					return v;
				}
				bet = Math.min(bet, v);
			}
			return v;

		}
	}

	ArrayList<GameBoard> getPossibleBoards(GameBoard state) {
		ArrayList<GameBoard> subelements = new ArrayList<GameBoard>();
		for (int i=0; i<7; i++) {

			if(state.isValidPlay(i)) {
				GameBoard tempChild = new GameBoard(state.getGameBoard());
				tempChild.playPiece(i);
				subelements.add(tempChild);
			}
		}
		return subelements;

	}

	public int utility(GameBoard ongoingplay){
		if(this.player==1) {
			if(ongoingplay.getScore(1) > ongoingplay.getScore(2)) {
				int utility_value=Integer.MAX_VALUE;
				return utility_value;
			}
			else if(ongoingplay.getScore(2) > ongoingplay.getScore(1)) {
				int utility_value=Integer.MIN_VALUE;
				return utility_value;
			}
			else {
				int utility_value=0;
				return utility_value;
			}
		}
		else {
			if(ongoingplay.getScore(2) > ongoingplay.getScore(1)) {
				int utility_value=Integer.MAX_VALUE;
				return utility_value;
			}
			else if(ongoingplay.getScore(1) > ongoingplay.getScore(2)) {
				int utility_value=Integer.MIN_VALUE;
				return utility_value;
			}
			else {
				int utility_value=0;
				return utility_value;
			}
		}
		
	}
	
	public int evaluate(GameBoard ongoingplay) {
		int et;
		if(this.player==1) {
			 et = (ongoingplay.getScore(1) - ongoingplay.getScore(2));
	
		}
		else {
			 et = (ongoingplay.getScore(2) - ongoingplay.getScore(1));

		}
		return et;


		

	}
}