/**
 *
 * Author : Jahnavi Nuthalapati
   UTA ID : 1001827251
 */
import java.io.*;

public class maxconnect4
{
  public static void main(String[] args) 
  {
    // check for the correct number of arguments
    if( args.length != 4 ) 
    {
      System.out.println("Four command-line arguments are needed:\n"
                         + "Usage: java [program name] interactive [input_file] [computer-next / human-next] [depth]\n"
                         + " or:  java [program name] one-move [input_file] [output_file] [depth]\n");

      exit_function( 0 );
     }
		
    // parse the input arguments
    String mode = args[0].toString();				// the game mode
    String input = args[1].toString();					// the input game file
    int curr_depth = Integer.parseInt( args[3] );  		
	boolean endPlayFlag=false;
    // create and initialize the game board
    GameBoard ongoingplay = new GameBoard( input );
    
    // create the Ai Player
    AiPlayer calculon = new AiPlayer();
		
    //  variables to keep up with the game
    int playColumn = 99;				//  the players choice of column to play
    boolean playMade = false;			//  set to true once a play has been made

    if( mode.equalsIgnoreCase( "interactive" ) ) 
    {
    	 System.out.print("\nMaxConnect-4 game\n");
    	    System.out.print("game state before move:\n");
    	    
    	    //print the current game board
    	    ongoingplay.printGameBoard();
    	    // print the current scores
    	    System.out.println( "Score: Player 1 = " + ongoingplay.getScore( 1 ) +
    				", Player2 = " + ongoingplay.getScore( 2 ) + "\n " );
	
    	String nextPlayer= args[2].toString();
    	System.out.println(ongoingplay.getCurrentTurn());
   if(ongoingplay.getCurrentTurn()==1) {
	   if(nextPlayer.equalsIgnoreCase("computer-next")) {
		   calculon.player=1;
		   //System.out.println("here");
	   }
	   else {
		   calculon.player=2;
	   }

   }
   if(ongoingplay.getCurrentTurn()==2) {
	   if(nextPlayer.equalsIgnoreCase("computer-next")) {
		   calculon.player=2;
		   
	   }
	   else {
		   calculon.player=1;
	   }

   }
  // System.out.println("Computer playing as:"+calculon.player);

    	while(ongoingplay.getPieceCount()<42) {
    	  if(nextPlayer.equalsIgnoreCase("human-next"))
      {
    	    /*if(ongoingplay.getPieceCount()>42)
    	    {
    		  System.out.println("Game Over");  
    	    }
    	    else
    	    {*/
    		  System.out.println("Enter a column to place the piece");
    		  BufferedReader buffer = new BufferedReader(new InputStreamReader(System.in));
    		  try
    		  {
    		  playColumn = Integer.parseInt(buffer.readLine().toString())-1;
    		  System.out.println("playcolum read"+playColumn);
    		  if(playColumn>7)
    			/*  playColumn+=1;
    		  while(ongoingplay.isValidPlay(playColumn)==false)
			  {
    			  		System.out.println("inside while");*/
				  System.out.println("Invalid column. Please try again");
			/*	  playColumn = Integer.parseInt(buffer.readLine().toString())-1;
			  }
    		  
    		  */
    		  if(ongoingplay.isValidPlay(playColumn)==true)
    		  {
    			  ongoingplay.playPiece(playColumn);
    			  System.out.println("Move " + ongoingplay.getPieceCount()
    			  					+ ": Player : Human, Column: " + (playColumn+1)+"\n");
    			  ongoingplay.printGameBoard();
    			  System.out.println( "Score: Player 1 = " + ongoingplay.getScore( 1 ) +
                          ", Player2 = " + ongoingplay.getScore( 2 ) + "\n " );
       
    			  ongoingplay.printGameBoardToFile( "human.txt" );
    			  System.out.println("*****Human Made Move*****");
       
    			  nextPlayer="computer-next";
    		  }
    		 
    		  }
    		  catch(Exception e)
    		  {
    			  e.printStackTrace();
    		  }
    	    }
   
    	  	else if(nextPlayer.equalsIgnoreCase("computer-next") )
    	  	{
    	  		
       
    	  		playColumn = calculon.findBestPlay(ongoingplay,curr_depth);
    	  		ongoingplay.playPiece(playColumn);
    	  		//System.out.println("entering computer move at "+ playColumn);
    	  		System.out.println("Move "+ongoingplay.getPieceCount() + ": "
    	  			  +"Player : Computer , Column : "+(playColumn+1));
    	  		System.out.println("Board State : ");
    	  		ongoingplay.printGameBoard();
    	  		ongoingplay.printGameBoardToFile("output.txt");
    	  		System.out.println( "Score: Player 1 = " + ongoingplay.getScore( 1 ) +
                        ", Player2 = " + ongoingplay.getScore( 2 ) + "\n " );
    	  		System.out.println("*****Computer Made Move*****");
    	  		nextPlayer="human-next";
    	  	  }
    	}
    	
    	System.out.println("*****GAME OVER*****" + "\n"+ "Final Game Board State: \n");
    	ongoingplay.printGameBoard();
    	System.out.println("---SCORE--- \n Player 1 :"+ ongoingplay.getScore(1)+ "\nPlayer 2 : "+ongoingplay.getScore(2)+"\n");
    	
    	if(ongoingplay.getScore( 1 )>ongoingplay.getScore( 2 ))
    		System.out.println("PLAYER 1 WINS");
    
    else if(ongoingplay.getScore( 1 )<ongoingplay.getScore( 2 )) 
         System.out.println("PLAYER 2 WINS");
    else 
    		 System.out.println("ITS A DRAW");
        
	return;
    } 
			
    else if( mode.equalsIgnoreCase( "one-move" ) ) 
    {

    		String output = args[2].toString();				
    
    		System.out.print("\nMaxConnect-4 game\n");
    		System.out.print("Game state before move:\n");
    
    		//print the current game board
    		ongoingplay.printGameBoard();
    		// print the current scores
    		System.out.println( "Score: Player 1 = " + ongoingplay.getScore( 1 ) +
			", Player2 = " + ongoingplay.getScore( 2 ) + "\n " );
    		
    		if(ongoingplay.getCurrentTurn()==1)
    			calculon.player=1;
    		else
    			calculon.player=2;
    
    		if( ongoingplay.getPieceCount() < 42 ) 
    		{
    			int current_player = ongoingplay.getCurrentTurn();
    			// AI play - random play
    			playColumn = calculon.findBestPlay( ongoingplay,curr_depth);
    			//System.out.println("Column Playcolumn "+ playColumn); //debug
    			// play the piece
    			ongoingplay.playPiece( playColumn );
        	
    			// display the current game board
    			System.out.println("move " + ongoingplay.getPieceCount() 
                           + ": Player " + current_player
                           + ", column " + playColumn);
    			System.out.print("game state after move:\n");
    			ongoingplay.printGameBoard();
    
    			// print the current scores
    			System.out.println( "Score: Player 1 = " + ongoingplay.getScore( 1 ) +
                            ", Player2 = " + ongoingplay.getScore( 2 ) + "\n " );
        
    			ongoingplay.printGameBoardToFile( output );
    		}
    		else 
    		System.out.println("\nI can't play.\nThe Board is Full\n\nGame Over");
    
    }
    else if(!(mode.equalsIgnoreCase("interactive")|| mode.equalsIgnoreCase("one-move")))
    			System.out.println("\n" + mode + " is an unrecognized game mode \n try again. \n");
	
    
} 
  private static void exit_function( int value )
  {
      System.out.println("exiting from MaxConnectFour.java!\n\n");
      System.exit( value );
  }
} // end of class connectFour
