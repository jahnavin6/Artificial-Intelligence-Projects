
Student Name 	        Jahnavi Nuthalapati
UTA ID  	        1001827251
Programming Language    Java

Code Structure

The implemented program has three classes:  


1) MaxConnect4.java - Optimal moves are found by using this class which has the function named findBestPlay() and gets the input when it's the human's turn.

2) AiPlayer.java - By using this file, an algorithm named alpha-beta pruning is implemented.

3) GameBoard.java - This displays the board User Interface, board score and move of the player about to make where the Gameboard is created. 

Execution

(In Terminal)

1) Program Compilation : javac GameBoard.java, javac AiPlayer.java, javac maxconnect4.java
			
2) Program Execution
 
---- One move Mode - java maxconnect4 one-move <input file> <output file> <depth>
(Eg : java maxconnect4 one-move input1.txt result.txt 4) 

---- In Interactive mode - java maxconnect4 interactive <input file> <human-next/computer-next> <depth>
(Eg : java maxconnect4 interactive input1.txt  computer-next 6) 

According to AI logic, The program either takes user input or plays the next move, where it depends on player who'll be mentioned next.


References:

--- https://www.cs.cornell.edu/courses/cs2110/2014sp/assignments/a4/A4ConnectFour.pdf
--- https://users.soe.ucsc.edu/~karplus/abe/Science_Fair_2010_report.pdf
--- https://www.researchgate.net/profile/Adnan_Shaout/publication/3648988_The_development_of_fuzzy_logic_based_controller_for_semi-active_suspension_system/links/564272cb08aec448fa6253c7/The-development-of-fuzzy-logic-based-controller-for-semi-active-suspension-system.pdf


